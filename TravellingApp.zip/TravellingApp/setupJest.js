require('jest-fetch-mock').enableMocks()
