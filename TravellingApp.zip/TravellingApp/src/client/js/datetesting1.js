function datechecker1(startdatetime,enddatetime) {

    if (startdatetime >= enddatetime) {

        return null;
    }

}

export {datechecker1}