function datechecker2(startdatetime,currentdate) {

    if (currentdate > startdatetime) {

        return null;
    }

}

export {datechecker2}