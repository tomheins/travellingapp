import {test} from "./js/app";
import './styles/fonts.css';
import './styles/style.css'
import './styles/laptopview.css'
import './styles/mobileview.css'
import './img/travel.jpg';

console.log("Adding javascript");
console.log(test());


export{

    test
}